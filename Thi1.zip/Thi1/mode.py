#การกำหนดรูปแบบภาพ
import cv2
images =cv2.imread("images/cat4.jpg")
imageresize=cv2.resize(images,(500,500))

cv2.imshow("RMUTP",imageresize)
cv2.waitKey(delay=9000)
cv2.destroyAllWindows()
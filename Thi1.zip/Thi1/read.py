#การอ่านภาพ
import cv2
img =cv2.imread("images/cat3.jpg")
print(type(img.ndim))
print(img)

#การแสดงภาพ
import cv2
img =cv2.imread("images/cat3.jpg")
cv2.imshow('',img)
cv2.waitKey(delay=9000)
cv2.destroyAllWindows()